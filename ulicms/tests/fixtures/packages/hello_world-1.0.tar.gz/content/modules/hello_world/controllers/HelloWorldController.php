<?php
class HelloWorldController extends MainClass {
	public function render() {
		return "Hello World!";
	}
}