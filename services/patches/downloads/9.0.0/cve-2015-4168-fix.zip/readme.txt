Ankit Bharathan of provensec llc discovered another CSRF security issue affecting HTTP GET requests. Thanks to him for reporing this issue. 
All versions of UliCMS are affected.

An attacker could get an user to click on a manipulated link, which executes actions like the deletion of a dataset.

Since it will not be checked, if the action is executed directly from UliCMS backend or from external the dataset will be deleted without a confirmation.

The threatment level is rated as medium. The vulnerability has the CVE-ID CVE-2015-4168.

This is the patch for UliCMS 9.0.0 that fixes the issue.
Copy the content of the "patch" folder to the main directory of your UliCMS installation and replace already existing files.
