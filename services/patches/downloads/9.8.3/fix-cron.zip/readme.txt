cronjobs of modules were not run.

This patch fixes the bug.