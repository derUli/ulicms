This patch fixes an XSS security issue in integration of Facebook' comment System.
Simply replace the file "comments/facebook.php" on your webserver with the file included in the "patch" folder.

All UliCMS Versions are affected.