<?php 
class config{

var $mysql_server="";
var $mysql_user="";
var $mysql_password="";
var $mysql_database="";
var $mysql_prefix="";

}