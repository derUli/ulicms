<?php
require_once "installer.php";
?>