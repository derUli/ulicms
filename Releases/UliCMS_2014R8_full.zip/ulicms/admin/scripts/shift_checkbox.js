$(window).load(function(){
   $("input[type='checkbox']").shiftClick({'cache': false});
});