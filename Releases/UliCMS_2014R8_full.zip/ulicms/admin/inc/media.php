﻿<?php if(defined("_SECURITY")){
     ?>

<h2>Medien</h2>
<strong>Bitte wählen Sie einen Dateityp aus:</strong><br/>
<a href="index.php?action=images">Bilder</a><br/>
<a href="index.php?action=flash">Flash</a><br/>
<a href="index.php?action=files">Dateien</a><br/>






<?php }
?>
