<h1>Einstellungen</h1>
<p><a href="index.php?action=settings_simple">Grundeinstellungen</a>
<br/><a href="index.php?action=design">Design</a>
<br/>
<a href="index.php?action=spam_filter">Spamfilter</a>
<br/>
<a href="index.php?action=cache">Cache</a>
<br/>
<a href="index.php?action=motd">MOTD</a>
<br/>
<a href="?action=pkg_settings">Paketquelle</a>
<br/>
<a href="index.php?action=logo_upload">Logo</a>
<br/>
<a href="index.php?action=languages">Sprachen</a>
<br/>
<a href="index.php?action=settings">Experteneinstellungen</a>
</p>