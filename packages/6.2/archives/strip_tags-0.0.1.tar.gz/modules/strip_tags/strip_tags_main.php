<?php 
function strip_tags_render(){
  return "";
}
?>