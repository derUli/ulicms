<?php 

// Hier URL zu Drucksymbol einfügen
define("PRINT_ICON_URL", "/content/images/drucksymbol.gif");

function full_url()
{
    $s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
    $sp = strtolower($_SERVER["SERVER_PROTOCOL"]);
    $protocol = substr($sp, 0, strpos($sp, "/")) . $s;
    $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
    return $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $_SERVER['REQUEST_URI'];
}

if(in_array("print_version", getAllModules())){
// Diese Funktion hier muss in einem Template aufgerufen werden,
// um den Drucklink für die aktuelle Seite auszugeben.
function printVersionLink(){

   $url = full_url();
   if(strpos($url, '?') !== false)
      $url = $url."&print";
   else
      $url = $url."?print";
   
   $url = htmlspecialchars($url);
   $html = "<a href=\"$url\" rel=\"nofollow\" target=\"_blank\"><img src=\"".PRINT_ICON_URL."\" alt=\"Drucken\" title=\"Drucken\"></a>";
   
   echo $html;
}

} else{
  // dummy function
  function printVersionLink(){}
}

?>