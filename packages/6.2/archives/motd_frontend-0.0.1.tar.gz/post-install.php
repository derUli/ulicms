<?php 
setconfig("cache_disabled", "disabled");
?>