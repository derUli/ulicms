<?php 


function fullcalendar_version(){
   return array(0,0,1);
}

function fullcalendar_render(){
   return "<div id='loading' style='display:none'>loading...</div>
<div id='fullcalendar'></div>";
}
?>