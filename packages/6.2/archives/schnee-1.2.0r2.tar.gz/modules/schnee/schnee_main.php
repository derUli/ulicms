<?php 
function schnee_render(){
   return "";
}
?>
