<?php 
setconfig("blog2twitter_consumer_key", "XXXXXXXXXXXXXXXXXXX");
setconfig("blog2twitter_consumer_secret", "XXXXXXXXXXXXXXXXXXX");
setconfig("blog2twitter_access_token", "XXXXXXXXXXXXXXXXXXX");
setconfig("blog2twitter_access_token_secret", "XXXXXXXXXXXXXXXXXXX");
?>