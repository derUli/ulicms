<link rel="stylesheet" type="text/css" href="<?php echo getModulePath("css3_hyphens")?>hyphens.css"/>
