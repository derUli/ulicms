<?php 
function css3_hyphens_render(){
   return "";
}
?>
