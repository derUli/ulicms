<br/><br/>
<?php
if(getconfig("comment_mode") != "off"){
   comments();
}?>

</div>
<div class="clear"></div>
<br/>
<div id="nav_bottom">
<?php menu("bottom")?>
</div>
<div id="footer">
Powered By <a href="http://www.ulicms.de" target="_blank">UliCMS</a> | &copy; <?php year()?> by <?php homepage_owner()?><br/><a href="http://www.publicdomainpictures.net/view-image.php?image=1105&picture=hund" target="_blank">Hund</a> von Peter Griffin
</div>

</div>
</body>
</html>