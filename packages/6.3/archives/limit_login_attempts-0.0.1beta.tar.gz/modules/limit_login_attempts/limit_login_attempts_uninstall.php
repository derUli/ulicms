<?php 
deleteconfig("max_login_attempts");
?>
