<?php 
if(!isset($_SESSION["failed_login_attempts"]))
   $_SESSION["failed_login_attempts"] = 0;

if(!isset($_SESSION["max_login_attempts"])){
  $max_login_attempts = getconfig("max_login_attempts");
  if($max_login_attempts)
     $_SESSION["max_login_attempts"] = $max_login_attempts;
  else
     $max_login_attempts = 999;
}

if(isset($_POST["login"])){

   if($_SESSION["failed_login_attempts"] >= $_SESSION["max_login_attempts"] - 1){
      echo '<script type="text/javascript">
      window.onload = function(){
         alert("Sie haben die Anzahl der maximalen Loginversuche überschritten. Ihr Zugang wurde gesperrt")
      }
      </script>';
      db_query("UPDATE ".tbname("admins"). " SET `group` = 0 WHERE username ='".mysql_real_escape_string($_POST["user"])."'");
   } else{
   
   $sessionData = validate_login($_POST["user"], $_POST["password"]);
   if($sessionData){
      register_session($sessionData, true);
      $_SESSION["failed_login_attempts"] = 0;
   } else {
     $_SESSION["failed_login_attempts"] += 1;
   }
}

}

?>
