<?php 
if(isset($_POST["login"])){

   if($_SESSION["failed_login_attempts"] - 1 >= $_SESSION["max_login_attempts"]){
      echo '<script type="text/javascript">
      window.onload = function(){
         alert("Sie haben die Anzahl der maximalen Loginversuche überschritten.\nIhr Zugang wurde gesperrt!")
      }
      </script>';   
   } else{
   $sessionData = validate_login($_POST["user"], $_POST["password"]);
   if($sessionData){
      register_session($sessionData, true);
      $_SESSION["failed_login_attempts"] = 0;
   } else {
     $_SESSION["failed_login_attempts"] += 1;
     
   }
}

}

?>
