<?php 
if(!isset($_SESSION["failed_login_attempts"]))
   $_SESSION["failed_login_attempts"] = 0;

if(!isset($_SESSION["max_login_attempts"])){
  $max_login_attempts = getconfig("max_login_attempts");
  if($max_login_attempts)
     $_SESSION["max_login_attempts"] = $max_login_attempts;
  else
     $max_login_attempts = 999;
}

   if($_SESSION["failed_login_attempts"] - 1 >= $_SESSION["max_login_attempts"]){
      die(nl2br("Sie haben die Anzahl der maximalen Loginversuche überschritten.\nIhr Zugang wurde gesperrt"));
   }
?>
