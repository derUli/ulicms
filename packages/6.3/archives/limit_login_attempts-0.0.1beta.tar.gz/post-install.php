<?php 
   setconfig("max_login_attempts", "5");
?>
