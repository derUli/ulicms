</div>
</div>
<div class="footer">
<?php menu("bottom");?>

<div id="copyright">&copy; <?php year()?> by <span id="owner"><?php homepage_owner();?></span></div>
</div>
</body>
</html>