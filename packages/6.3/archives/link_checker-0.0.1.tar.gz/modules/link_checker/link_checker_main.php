<?php 
function link_checker_render(){
   return "";
}
?>
