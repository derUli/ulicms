<?php 
/**
SenselessSuperBunt – Google anmalen
Plugin für UliCMS
Basiert auf folgendes Wordpress-Plugin http://www.anwaelte-in-vulkane-werfen.de/376/wordpress-plugin-senselesssuperbunt-google-anmalen/

**/

function senseless_superbunt_render(){
   return "";
}
?>