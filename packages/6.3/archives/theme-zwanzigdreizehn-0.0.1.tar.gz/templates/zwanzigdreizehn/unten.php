<p class="banner"><?php random_banner()?></p>
</div>
</div>
<div style="clear:both;">
</div>
<div class="menu">
<?php menu("bottom")?>
</div>
</div>
<div class="copyright">
&copy; <?php year()?> by  <?php homepage_owner()?>
</div>

</body>
</html>

