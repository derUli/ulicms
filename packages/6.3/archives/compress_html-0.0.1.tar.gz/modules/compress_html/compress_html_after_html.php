<?php
    // end output buffer and echo the page content
    ob_end_flush();
 
    //  this function gets rid of tabs, line breaks, and white space
?>
