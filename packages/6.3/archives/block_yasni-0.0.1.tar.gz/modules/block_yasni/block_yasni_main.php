<?php 
function block_yasni_render(){
   return "";
}
?>