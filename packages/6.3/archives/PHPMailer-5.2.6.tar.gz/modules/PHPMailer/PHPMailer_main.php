<?php 
function PHPMailer_render(){
   return "";
}
?>
