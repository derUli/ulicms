<?php 
setconfig("hide_meta_generator", "hide");
?>
