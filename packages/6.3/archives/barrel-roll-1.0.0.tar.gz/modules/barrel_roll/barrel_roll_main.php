<?php 
function barrel_roll_render(){

  return "";
}
?>