
<style type="text/css">
textarea#sql_code{
width:98%;
height:200px;
margin:auto;
text-align:left;
}

form{
text-align:center;
}

</style>