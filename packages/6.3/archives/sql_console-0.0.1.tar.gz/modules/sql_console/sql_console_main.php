<?php 
function sql_console_render(){
  return "";
}
?>