<br/>
<?php random_banner()?>
<br/>
</div>
</body>
</html>