<?php 
function motd_frontend_render(){
   return "";
}
?>