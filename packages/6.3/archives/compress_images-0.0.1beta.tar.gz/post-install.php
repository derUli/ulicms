<?php 
setconfig("image_quality", "70");
?>
