<?php 
function compress_images_render(){
  return "";
}
?>
