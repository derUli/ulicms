<?php 
deleteconfig("image_quality");
?>
