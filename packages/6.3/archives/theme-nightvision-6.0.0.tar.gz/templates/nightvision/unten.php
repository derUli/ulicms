			
		</div>
		
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="categories">
				<h2>Empfohlene Links</h2>
				<ul>
				<?php menu("right")?>
				</ul>
			</li>
			
			
			<li>
				<h2>Sonstiges</h2>
				<ul>
					<?php menu("bottom")?>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<p class="legal">
		&copy; <?php year()?> <?php homepage_owner()?>. All Rights Reserved.
		&nbsp;&nbsp;&bull;&nbsp;&nbsp;
		Design by <a href="http://www.freecsstemplates.org">FCT</a>
		&nbsp;&nbsp;&bull;&nbsp;&nbsp;
		Icons by <a href="http://famfamfam.com/">FAMFAMFAM</a>. </p>
	<p class="links">
		<a href="http://validator.w3.org/check/referer" class="xhtml" title="This page validates as XHTML">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a>
		&nbsp;&bull;&nbsp;
		<a href="http://jigsaw.w3.org/css-validator/check/referer" class="css" title="This page validates as CSS">Valid <abbr title="Cascading Style Sheets">CSS</abbr></a>
	</p>
</div>
</div>
<!-- end footer -->
</body>
</html>
