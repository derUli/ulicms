<?php 
include_once getModulePath("proxy_real_ip")."proxy_real_ip_before_init.php";