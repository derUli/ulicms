<?php 
if(file_exists("../json-events.php"))
   @unlink("../json-events.php");
?>