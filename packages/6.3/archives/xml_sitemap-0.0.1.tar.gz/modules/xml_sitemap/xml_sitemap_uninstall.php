<?php 
if(file_exists("../sitemap.xml"))
   @unlink("../sitemap.xml");
?>
