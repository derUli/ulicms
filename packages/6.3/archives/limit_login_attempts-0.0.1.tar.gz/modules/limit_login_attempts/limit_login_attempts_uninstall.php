<?php 
db_query("DROP TABLE ".tbname("failed_logins"));
?>