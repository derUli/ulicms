<?php 
function jquery_render(){
   return "";
}
?>