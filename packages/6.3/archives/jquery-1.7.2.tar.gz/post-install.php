<p>Variable anlegen (jquery_disabled_on)</p>
<?php 
if(!getconfig("jquery_disabled_on"))
   setconfig("jquery_disabled_on", "");
?>