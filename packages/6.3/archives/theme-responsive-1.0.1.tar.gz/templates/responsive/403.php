<h1>Zugriff verweigert</h1>
<p>Sie haben leider nicht die notwendige Berechtigung, um auf diese Seite zugreifen zu dürfen.
<img src="<?php echo getTemplateDirPath("default");?>schulterzuck.gif" alt=":Ich kann doch auch nichts dafür:"/></p>
