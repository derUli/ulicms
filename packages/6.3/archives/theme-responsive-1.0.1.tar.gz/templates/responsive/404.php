<h1>Nicht gefunden.</h1>
<p>Diese Seite existiert leider nicht mehr.
<img src="<?php echo getTemplateDirPath("default");?>schulterzuck.gif" alt=":Ich kann doch auch nichts dafür:"/></p>
