</div>
<div id="footer">
<div id="copyright">(C) <?php year()?> by <?php homepage_owner()?> | <a href="http://www.ulicms.de" target="_blank">Powered by UliCMS</a></div>
<div id="menu-bottom-container"><?php menu("bottom")?></div>
</div>
</div>
</body>
</html>