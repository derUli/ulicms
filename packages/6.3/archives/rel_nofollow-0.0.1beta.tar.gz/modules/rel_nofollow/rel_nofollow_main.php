<?php 
function rel_nofollow_render(){
   return "";
}
?>