<script type="text/javascript">
if (top != self)
  top.location = self.location;
</script>
