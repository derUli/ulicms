<?php 
function break_frames_render(){

   return "";
}
?>