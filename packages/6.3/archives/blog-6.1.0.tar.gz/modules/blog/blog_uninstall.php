<?php 
if(file_exists("../blog_rss.php"))
   @unlink("../blog_rss.php");
?>