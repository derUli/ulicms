<?php 
function code_highlighting_render(){
   return "";
}
?>