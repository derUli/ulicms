<?php 
function exec_php_render(){
  
  return "";
}
?>
