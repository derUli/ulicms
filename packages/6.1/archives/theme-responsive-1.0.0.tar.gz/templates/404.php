<h1>Nicht gefunden.</h1>
<p>Diese Seite existiert leider nicht mehr.
<img src="templates/schulterzuck.gif" alt=":Ich kann doch auch nichts daf�r:"/></p>