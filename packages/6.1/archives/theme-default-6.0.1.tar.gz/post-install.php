<?php 
setconfig("header-background-color", "rgb(35, 148, 96)");
setconfig("body-background-color", "rgb(255,255,255)");
setconfig("body-text-color", "rgb(0,0,0)");
?>