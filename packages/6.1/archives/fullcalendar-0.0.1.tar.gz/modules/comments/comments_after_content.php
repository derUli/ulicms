<?php 
if(function_exists("comments")){
   echo "<br/>";
   comments();
}
?>