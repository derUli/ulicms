<br/>
<?php random_banner()?>
<br/>
<?php comments();?>

</div>
</body>
</html>