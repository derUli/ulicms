<?php 
function test_render(){
	return "funktioniert!";
}
?>