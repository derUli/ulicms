<h1>Zugriff verweigert</h1>
<p>Sie haben leider nicht die notwendige Berechtigung, um auf diese Seite zugreifen zu d�rfen.
<img src="templates/schulterzuck.gif" alt=":Ich kann doch auch nichts daf�r:"/></p>